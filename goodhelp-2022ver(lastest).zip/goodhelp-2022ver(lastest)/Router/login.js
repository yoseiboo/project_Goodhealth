const express = require('express');
const path = require('path');
const cookieSession = require('cookie-session');
const bcrypt = require('bcrypt');
const dbConnection = require('./database');
const { body, validationResult } = require('express-validator');
const router = express.Router()






//set key ให้
router.use(cookieSession({
    name: 'session',
    keys: ['key1', 'key2'],
    maxAge:  3600 * 1000 // 1hr
}));

//ให้เเสดงหน้าlogin
const ifNotLoggedin = (req, res, next) => {
    if(!req.session.isLoggedIn){
        return res.send('Login');
    }
    next();
}
const ifLoggedin = (req,res,next) => {
    
    if(req.session.isLoggedIn){
        return res.redirect('/login');
    }
    // console.log('จ๊ะเอ๋0');
    next();
}
//หลังจากกรอกข้อมูลให้หา ID ในData
router.get('/', ifNotLoggedin, (req,res,next) => {
    dbConnection.execute("SELECT `name` FROM `users` WHERE `id`=?",[req.session.userID])
    .then(([rows]) => {
        res.render('Login',{
            name:rows[0].name
        });
    });
    
});

//หา Email ในData
router.post('/', [
    body('user_email').custom((value) => {
        return dbConnection.execute('SELECT Email FROM users WHERE Email= ?', [value])
        .then(([rows]) => {
            if(rows.length == 1){
                return true;
                
            }
            return Promise.reject('Invalid Email Address!');
            
        });
    }),
    body('user_pass','Password is empty!').trim().not().isEmpty(),
], (req, res) => {
    // console.log('จ๊ะเอ๋2');
    const validation_result = validationResult(req);
    const {user_pass, user_email} = req.body;
    if(validation_result.isEmpty()){
        
        dbConnection.execute("SELECT * FROM `users` WHERE `email`=?",[user_email])
        .then(([rows]) => {
            bcrypt.compare(user_pass, rows[0].password).then(compare_result => {
                if(compare_result === true){
                    req.session.isLoggedIn = true;
                    req.session.userID = rows[0].id;
                    // console.log('เกือบแล้วนะตะเอง');
                    res.send('Login Success');
                    
                
                    
                }
                else{
                    req.session.isLoggedIn = false;
                    res.send('Invalid Password!')
                    res.send('Login',{
                    login_errors:['Invalid Password!']
                        
                    });
                }
            })
            .catch(err => {
                if (err) throw err;
            });


        }).catch(err => {
            if (err) throw err;
        });
    }
    else{
        let allErrors = validation_result.errors.map((error) => {
            return error.msg;
        });
       
        res.send(`Login,{
            login_errors:${allErrors}
        }`);
    }
});
//logout เเละให้กลับไปหน้า home
router.get('/logout',(req,res)=>{
   
    req.session = null;
    res.redirect('/');
});


router.use('/', (req,res) => {
    res.status(404).send('<h1>404 Page Not Found!</h1>');
});

module.exports = router



