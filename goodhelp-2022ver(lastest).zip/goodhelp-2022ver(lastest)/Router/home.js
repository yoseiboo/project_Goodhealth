const express = require('express');
const path = require('path');
const cookieSession = require('cookie-session');
const bcrypt = require('bcrypt');
const dbConnection = require('./database');
const { body, validationResult } = require('express-validator');
const router = express.Router()

router.use(express.urlencoded({extended:false}));
router.use(express.json())

router.use(express.static('../public'))
//ให้Joinหาไฟล์ในviewsที่เป็นhtml    
router.set('views', path.join(__dirname,'views'));
router.set('view engine','html');

//set key ให้
router.use(cookieSession({
    name: 'session',
    keys: ['key1', 'key2'],
    maxAge:  3600 * 1000 // 1hr
}));


const ifgetHome = (req,res,next) => {
    if(!req.session.isLoggedIn){
        return res.render ('home');
    }
    next(); 
}
router.get('/home',ifgetHome,(req,res, next)=>{
    dbConnection.execute("SELECT `name` FROM `users` WHERE `id`=?",[req.session.userID])
    .then(([rows])=>{
        res.render('home', {
            name: rows[0].name
        })
  }).catch(err => {
    if (err) throw err;})
}) 



router.use('/', (req,res) => {
    res.status(404).send('<h1>404 Page Not Found!</h1>');
});

module.exports = router


