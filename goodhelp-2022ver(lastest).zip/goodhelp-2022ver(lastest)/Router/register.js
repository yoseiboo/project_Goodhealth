const express = require('express');
const path = require('path');
const cookieSession = require('cookie-session');
const bcrypt = require('bcrypt');
const dbConnection = require('./database');
const { body, validationResult } = require('express-validator');
const router = express.Router()


router.use(cookieSession({
    name: 'session',
    keys: ['key1', 'key2'],
    maxAge:  3600 * 1000 // 1hr
}));

//เเสดงหน้า Register
const ifLoggedin = (req, res, next) => {
    // if(!req.session.isLoggedIn){
    //     return res.send('Register');
    // }
    console.log(req.body);
    next();
}


//ไปยัง post เพื่อกรอกข้อมูลเเล้วนำไปเพิ่มข้อมูลใน Data
router.post('/', ifLoggedin, 

[
    body('email','Invalid email address!').isEmail().custom(async(value) => {
        console.log(value);
        return dbConnection.execute('SELECT email FROM users WHERE `email`=?', [value])
        .then(([rows]) => {
            if(rows.length > 0){
                return Promise.reject('This E-mail already in use!');
            }
            return true;
        });
    }),
    body('username','Username is Empty!').trim().not().isEmpty(),
    body('password','The password must be of minimum length 6 characters').trim().isLength({ min: 6 }),
],
(req,res,next) => {
    console.log('เข้ามาแล้วนะจ้ะ');
    const validation_result = validationResult(req);
    const {Fullname,username,password,Email,PhoneNumber,Gender} = req.body;
   
    if(validation_result.isEmpty()){
        //เเปลงค่าให้เป็น Token
        bcrypt.hash(password, 12).then((password_pass) => {
           console.log(password_pass);
            dbConnection.execute("INSERT INTO `users`(`Fullname`,`username`,`password`,`Email`,`PhoneNumber`,`Gender`) VALUES(?,?,?,?,?,?)"
            ,[Fullname,username,password_pass,Email,PhoneNumber,Gender])
            .then(result => {
                res.send(`your account has been created successfully, Now you can <a href="/">Login</a>`);
            }).catch(err => {
                
                if (err) throw err;
            });
        })
        .catch(err => {
            
            if (err) throw err;
        })
    }
    else{
       
        let allErrors = validation_result.errors.map((error) => {
            return error.msg;
        });
     
        res.send('Register',{
            register_error:allErrors,
            old_data:req.body
        });
    }
});



router.use('/', (req,res) => {
    res.status(404).send('<h1>404 Page Not Found!</h1>');
});

module.exports = router;



