const express = require('express');
const cookieSession = require('cookie-session');
const dbConnection = require('./database');
const { body, validationResult } = require('express-validator');

const router = express.Router()


router.use(cookieSession({
    name: 'session',
    keys: ['key1', 'key2'],
    maxAge:  3600 * 1000 // 1hr
}));

// const ifLoggedin = (req,res, next)=>{
//     if (req.session.isLoggedIn) {
//         return res.render('medicine')
//     }
//     next();
// }

router.post('/', //ifLoggedin,
[
    body('first_name','first_name is Empty!').trim().not().isEmpty(),
    body('last_name','last_name is Empty!').trim().not().isEmpty(),
    body('age','age is Empty!').trim().not().isEmpty(),
    body('sex','sex is Empty!').trim().not().isEmpty(),
    body('Height','high is Empty!').trim().not().isEmpty(),
    body('mail','email is Empty!').trim().not().isEmpty(),
    body('Phone','Phone is Empty!').trim().not().isEmpty(),
    body('address','address is Empty!').trim().not().isEmpty(),
    body('province','province is Empty!').trim().not().isEmpty(),
    body('Country','Country is Empty!').trim().not().isEmpty(),
    body('symptom','symptom is Empty!').trim().not().isEmpty(),
    body('weight','weight is Empty!').trim().not().isEmpty()
],
(req,res,next)=>{
    const first_name = req.body.first_name
    const last_name = req.body.last_name
    const age = req.body.age
    const sex = req.body.sex
    const Height = req.body.Height
    const mail = req.body.mail 
    const Phone = req.body.Phone
    const address = req.body.address
    const province = req.body.province
    const Country = req.body.Country
    const symptom  = req.body.symptom
    const weight = req.body.weight

    dbConnection.execute ("INSERT INTO `medicine_delivery`(`first_name`,`last_name`,`age`,`sex`,`Height`,`mail`,`Phone`,`address`,`province`,`Country`,`symptom`,`weight`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
    ,[first_name,last_name,age,sex,Height,mail,Phone,address,province,Country,symptom,weight])

})



    module.exports = router

