ดึงไฟล์ Database ไปสร้างใน (MySQL Workbench) 
แล้ว Run terminal ของ index.js ได้เลยครับ