const medicine = async(EP)=>{
        const first_names = document.getElementById('first_name').value
        const last_names = document.getElementById('last_name').value
        const ages = document.getElementById('age').value
        const sexs = document.getElementById('sex').value
        const Heights = document.getElementById('Height').value
        const mails = document.getElementById('mail').value
        const phones = document.getElementById('phone').value
        const addresss = document.getElementById('address').value
        const provinces = document.getElementById('province').value
        const Countrys  = document.getElementById('Country').value
        const symptoms= document.getElementById('symptom').value
        const weights = document.getElementById('weight').value
        const Data = {'first_name':first_names,'last_name':last_names,'age':ages,'sex':sexs,'Height':Heights,'mail':mails,'phone':phones,'address':addresss,'province':provinces,'Country':Countrys,'symptom':symptoms,'weight':weights}
        console.log(Data);
        let fetcher = await fetch(EP,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Data)})
        const RES = await fetcher.text() 
        alert(RES)
        console.log(RES); 
 
}