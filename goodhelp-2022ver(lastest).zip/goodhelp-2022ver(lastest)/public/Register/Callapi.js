const Register = async(EP)=>{
    const fullname = document.getElementById('Fullname').value
    const usernames = document.getElementById('username').value
    const emails = document.getElementById('email').value
    const Phone = document.getElementById('phone').value
    const Password = document.getElementById('password').value
    // const Genders1 = document.getElementById('Gender1').value
    // const Genders2 = document.getElementById('Gender2').value
    const Gender = document.getElementsByName('gender')
    let gender = ''
    Gender.forEach((Element,i)=>{
        if(Gender[i].checked) gender = Gender[i].value    
    })
    const Data = {Fullname:fullname,username:usernames,Email:emails,PhoneNumber:Phone,password:Password,Gender:gender}
    console.log(Data);
    let fetcher = await fetch(EP,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Data)})
    const RES = await fetcher.text()
    console.log(RES)      
}