const Login = async(EP)=>{
    const Email = document.getElementById('email').value
    const Password = document.getElementById('password').value
    const Data = {'user_email':Email,'user_pass':Password}
    console.log(Data);
    let fetcher = await fetch(EP,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Data)})
    const RES = await fetcher.text() 
    alert(RES)
    console.log(RES); 
    window.location.href = '../intro/home2.html'
}