const express = require('express')
const app = express()
const PORT = 5000;

const loginRouter = require('./Router/login')
const registerRouter = require('./Router/register')
const medicineRouter = require('./Router/medicine')

app.use(express.urlencoded({extended:false}));
app.use(express.json())

app.use(express.static('./public'))

app.use("/login",loginRouter);
app.use("/register",registerRouter);
app.use("/medicine",medicineRouter)

app.listen(PORT , () =>{
    console.log('Server Run. . . ')
})